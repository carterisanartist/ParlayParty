
  # Parlay Party

  This is a code bundle for Parlay Party. The original project is available at https://www.figma.com/design/Rr56hE9Js53GeTL7VGAVb6/Parlay-Party.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  